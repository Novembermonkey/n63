from utils import match_password
from database import get_user, insert_user
from models import UserRole

sessions = {}

def create_session(username, user_dict):
    sessions[username] = user_dict

def create_dict(data):
    user_dict = {
                 'id': 0,
                 'username': '',
                 'password': '',
                 'role': '',
                 'email': '',
                 'login_try_count': 0}

    for index, key in enumerate(user_dict):
        user_dict[key] = data[index]
    return user_dict


def login_page(username,raw_password):
    assert username, "Username can't be none"
    assert raw_password, "Password can't be none"
    res = get_user(username)
    if not res:
        return "User not found"
    user_dict = create_dict(res)
    user, hashed_password = user_dict['username'], user_dict['password']
    if not match_password(raw_password, hashed_password):
        user_dict["login_try_count"] += 1
        return "Incorrect password"
    create_session(username, user_dict)
    return "User logged successfully"




def sign_up(username, password, email: str|None = None, role: UserRole | None = UserRole.USER.value):
    insert_user(username, password, email, role)



print(login_page(input("Username: "), input("Password: ")))